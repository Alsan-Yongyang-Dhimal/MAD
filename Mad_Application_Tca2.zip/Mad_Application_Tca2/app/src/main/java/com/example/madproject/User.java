package com.example.madproject;

import java.util.ArrayList;

public class User
{
    //array list user
    public static ArrayList<com.example.madproject.User> userArrayList = new ArrayList<>();
    //user edit
    public static String USER =  "userEdit";

    public String username;

    //getting username
    public User( String username)
    {

        this.username = username;

    }
    //Array list for non delete user
    public static ArrayList<com.example.madproject.User> nonDeletedUser()
    {
        //array list
        ArrayList<com.example.madproject.User> nonDeleted = new ArrayList<>();
        //user
        for(com.example.madproject.User user : userArrayList)
        {

            nonDeleted.add(user);
        }

        return nonDeleted;
    }
    //get username
    public String getUsername()
    {
        return username;
    }
    //set username
//    public void setUsername(String title)
//    {
//        this.username = username;
//    }


}