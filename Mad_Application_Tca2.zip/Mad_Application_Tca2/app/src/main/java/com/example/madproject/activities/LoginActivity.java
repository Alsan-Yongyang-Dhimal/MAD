package com.example.madproject.activities;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.madproject.Post;
import com.example.madproject.User;
import com.example.madproject.DBHelper;
import com.example.madproject.R;

public class LoginActivity extends AppCompatActivity {
    EditText Email, Password;
    Button Login;
    DBHelper Database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //finding the respective id
        Email =  findViewById(R.id.usernameLogin);
        Password =  findViewById(R.id.passwordLogin);
        Login =  findViewById(R.id.btnsigninLogin);
        Database = new DBHelper(this);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               //converting the user and pass to text and string
                String user = Email.getText().toString();
                String password = Password.getText().toString();
                //checking the user and password
                if(user.equals("")||Password.equals(""))
                    Toast.makeText(LoginActivity.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
                else{
                    //Check username and  password form the database
                    Boolean checkUserPass = Database.checkusernameandpassword(user, password);
                    //checking the given username and password is correct or not
                    if(checkUserPass==true){
                        //if the username and password is matched then log in
                        Toast.makeText(LoginActivity.this, "Login successfully", Toast.LENGTH_SHORT).show();
                        //intent to jump form this activity to home activity
                        Intent login1 = new Intent(getApplicationContext(), HomeActivity.class);
                        //putting extra  data to users
                        login1.putExtra(User.USER, user);
                        startActivity(login1);
                    }else{
                        //If username and password don't matched;
                        Toast.makeText(LoginActivity.this, "Incorrect email or Password", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

    }

}