package com.example.madproject;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.example.madproject.Comment;
import com.example.madproject.Post;
import com.example.madproject.User;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Calendar;
public class DBHelper extends SQLiteOpenHelper {

    //Database Helper
    public static DBHelper db;
    //creating the database
    public static final String DB_NAME = "database";
    //giving the version
    public static final int DB_VERSION = 1;
    //table name post
   public static final String TABLE_NAME = "Post";
    //giving the counter
   public static final String COUNTER = "Counter";
    //giving the field
    public static final String ID = "Id";
    //giving the title
    public static final String TITLE= "Title";
    //giving the desc
    public static final String DESC = "=Description";
    //post date
    public static final String DATE_POSTED = "DatePosted";
    //delete
    public static final String DELETED = "Delete";

    @SuppressLint("SimpleDateFormat")
    //creating the date format for the upload date
    public static final DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
    public DBHelper(Context context) {
        super(context, DB_NAME, null,DB_VERSION);
    }

    public static DBHelper instanceOfDatabase(Context context)
    {
        // DBHelper class
        if(db == null)
            //creating the  instance
            db = new DBHelper(context);
            return db;
    }

    @Override
    public void onCreate(SQLiteDatabase MyData) {
        //Creating table called users
        MyData.execSQL("create Table users(Fullname Text Primary key, Email, Password, RegDate)");

        StringBuilder SqlTable1;
        //creating PostTable
        SqlTable1 = new StringBuilder()
                .append("Create Table ")
                .append(TABLE_NAME)
                .append("(")
                .append(COUNTER)
                .append(" Integer Primary Key AutoIncrement, ")
                .append(ID)
                .append(" int, ")
                .append(TITLE)
                .append(" Text, ")
                .append(DESC)
                .append(" Text, ")
                .append(DATE_POSTED)
                .append(" Text ")
                .append(DELETED)
                .append(" Text)");
        //creating string builder
        StringBuilder C = new StringBuilder()
                .append("Create Table ")
                .append("Comments")
                .append("(")
                .append(COUNTER)
                .append(" Integer Primary Key AutoIncrement , ")
                .append(ID)
                .append(" Int, ")
                .append(TITLE)
                .append(" Text, ")
                .append(DESC)
                .append(" Text, ")
                .append(DATE_POSTED)
                .append(" Text, ")
                .append(DELETED)
                .append(" TEXT)");
        //executing the sql
        MyData.execSQL(SqlTable1.toString());
        //executing the sql
        MyData.execSQL(C.toString());

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyData, int i, int i1) {
        //Drop Table If Users Table Exists
        MyData.execSQL("Drop Table if exists users");
    }

    public void postList()
    {
        //Readable function in sql database
        SQLiteDatabase sql = this.getReadableDatabase();

        try (Cursor result1 = sql.rawQuery("SELECT * FROM " + TABLE_NAME, null))
        {
            //Check to see If The Object is Empty
            if(result1.getCount() != 0)
            {

                while (result1.moveToNext())
                {
                    int Id = result1.getInt(1);
                    //email
                    String email = result1.getString(2);
                    //delete
                    String stringDelete = result1.getString(4);
                    //password
                    String pass = result1.getString(3);

                    //delete
                    Date delete = getDateFromString(stringDelete);
                    //current time for post
                    Date Time = Calendar.getInstance().getTime();
                    //converting all to Strings
                    Post newPost1 = new Post(Id,email,pass,Time.toString(),delete);
                    //To construct a single array, add each data to arrayAdapter
                    Post.postArrayList.add(newPost1);
                }
            }
        }
    }
    public void commentList()
    {

        SQLiteDatabase sql = this.getReadableDatabase();

        try (Cursor result2 = sql.rawQuery("SELECT * FROM  Comments" + "  ", null))
        {
         //The provided Data is Empty Or Not
            if(result2.getCount() != 0)
            {
                //If Data is not empty
                while (result2.moveToNext())
                {
                   //for ID
                    int Id = result2.getInt(1);
                    //Title
                    String Title = result2.getString(2);

                    String Desc = result2.getString(3);

                    String StDelete = result2.getString(4);

                    Date delete = getDateFromString(StDelete);

                    Date Time = Calendar.getInstance().getTime();

                    Comment C = new Comment(Id,Title,Desc,Time.toString(),delete);
                   //Comment for adding
                    Comment.commentArrayList.add(C);
                }
            }
        }
    }
    public void User()
    {

        SQLiteDatabase sql = this.getReadableDatabase();

        try (Cursor result3 = sql.rawQuery("SELECT * FROM " + "users", null))
        {

            if(result3.getCount() != 0)
            {

                while (result3.moveToNext())
                {

                    String username = result3.getString(1);

                    User user1 = new User(username);

                    User.userArrayList.add(user1);
                }
            }
        }
    }
    public void addComment(Comment C)
    {

        SQLiteDatabase sql = this.getWritableDatabase();

        ContentValues CV = new ContentValues();
        CV.put(ID, C.getId());
        CV.put(TITLE,C.getTitle());
        CV.put(DESC, C.getDescription());
        CV.put("Posted_Date",C.getCommentedDate());
        CV.put(DELETED, getStringFromDate(C.getDeleted()));

        sql.insert(TABLE_NAME, null, CV);
    }
    public void addPost(Post P)
    {

        SQLiteDatabase sql = this.getWritableDatabase();

        ContentValues CV = new ContentValues();
        CV.put(ID, P.getId());
        CV.put(TITLE,P.getTitle());
        CV.put(DESC, P.getDescription());
        CV.put("Posted_Date",P.getPostedDate());
        CV.put(DELETED, getStringFromDate(P.getDeleted()));

        sql.insert(TABLE_NAME, null, CV);
    }


    public void updatePost(Post P)
    {

        SQLiteDatabase sql = this.getWritableDatabase();
        ContentValues CV = new ContentValues();

        CV.put(ID,P.getId());
        CV.put(TITLE, P.getTitle());
        CV.put(DESC,P.getDescription());

       CV.put(DELETED, getStringFromDate(P.getDeleted()));

        sql.update(TABLE_NAME, CV, ID + " =? ", new String[]{String.valueOf(P.getId())});
    }

    public Boolean insertData(String username, String password){

        SQLiteDatabase MyData = this.getWritableDatabase();
        ContentValues CV= new ContentValues();

        CV.put("Username", username);
        CV.put("Password", password);
        //Add all data to the database.
        long result = MyData.insert("users", null, CV);
        //insert to database
        //checking
        if(result==-1)
            return false;
        else
            return true;
    }

    public Boolean checkusername(String username) {
        //To write data to a database, use an instance of the WritableDatabase method in the SQLiteDatabase class
        SQLiteDatabase MyData = this.getWritableDatabase();

        Cursor c = MyData.rawQuery("Select * from users where username = ?", new String[]{username});
        if (c.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkusernameandpassword(String username, String password){
        //To write data to a database, use an instance of the WritableDatabase method in the SQLiteDatabase class
        SQLiteDatabase MyDB = this.getWritableDatabase();
        //Verify username and password
        Cursor cursor1 = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor1.getCount()>0)
            return true;
        else
            return false;
    }

      public String getStringFromDate(Date D)
    {
        //Format date
        if(D == null)
            return null;

        return dateFormat.format(D);
    }

    public Date getDateFromString(String S)
    {

        try
        {
            return dateFormat.parse(S);
        }
        catch (ParseException | NullPointerException e)
        {

            return null;
        }
    }
}