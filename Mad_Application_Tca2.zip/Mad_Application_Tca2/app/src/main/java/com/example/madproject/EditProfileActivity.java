package com.example.madproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.madproject.Post;
import com.example.madproject.User;
import com.example.madproject.DBHelper;

public class EditProfileActivity extends AppCompatActivity {
    public EditText Email;
    public EditText Password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        email();
        user();

    }
    public void email()
    {

        Email = findViewById(R.id.EmailEdit);
//        Password= findViewById


    }
    public void user()
    {
        Intent intent1 = getIntent();

        String selectUser = intent1.getStringExtra(User.USER);


        if (selectUser != null)
        {
            Email.setText(selectUser);
        }

    }

}