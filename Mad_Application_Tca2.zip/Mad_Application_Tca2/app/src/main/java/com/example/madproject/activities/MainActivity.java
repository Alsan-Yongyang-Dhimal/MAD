package com.example.madproject.activities;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.madproject.DBHelper;
import com.example.madproject.R;

public class MainActivity extends AppCompatActivity {

    EditText FullName,Email, password, rePassword,regDate;
    Button reg, Login;
    DBHelper Database;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //finding the id
        FullName =  findViewById(R.id.fullName);
        Email    =  findViewById(R.id.username);
        password =  findViewById(R.id.password);
        rePassword = findViewById(R.id.repassword);
        regDate   = findViewById(R.id.dateRegister);
        reg =  findViewById(R.id.registerbtn);
        Login =  findViewById(R.id.btnsignin);
        // database
        Database = new DBHelper(this);
        //when register button is clicked
        reg.setOnClickListener(view -> {
            //change the user text to string
            String full = FullName.getText().toString();
            String email = Email.getText().toString();
            String pass = password.getText().toString();
            String repass = rePassword.getText().toString();
            String reg = regDate.getText().toString();
            //Verify if the user and password or rePassword is empty or not
            if(full.equals("")||email.equals("")||pass.equals("")||repass.equals("")||reg.equals(""))
                Toast.makeText(MainActivity.this, "Please enter all Credentials", Toast.LENGTH_SHORT).show();
            else{
                //verify  the Password and rePassword matches or not
                if(pass.equals(repass)){
                    //Check the username from the database
                    Boolean checkuser = Database.checkusername(email);
                    if(checkuser==false){
                        //if doesnot insert the user and password
                        Boolean insert1 = Database.insertData(email, pass);
                        if(insert1==true){
                            //if user and pass matched register successfully
                            Toast.makeText(MainActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();

                        }else{
                            //if nothing matches
                            Toast.makeText(MainActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                        }
                    }
                    //else
                    else{
                        //if password or repassword doesnot match
                        Toast.makeText(MainActivity.this, "Incorrect Password", Toast.LENGTH_SHORT).show();

                    }
                }else{
                    // User Already Exists then
                    Toast.makeText(MainActivity.this, "User Already Exists", Toast.LENGTH_SHORT).show();

                }
            } });

        //when login button  clicked
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //move to another Activity
                Intent intent1 = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent1);
            }
        });
    }


}