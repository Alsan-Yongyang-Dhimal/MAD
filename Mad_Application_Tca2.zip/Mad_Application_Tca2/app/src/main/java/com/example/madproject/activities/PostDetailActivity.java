package com.example.madproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.madproject.CommentAdapter;
import com.example.madproject.PostAdapter;
import com.example.madproject.Comment;
import com.example.madproject.DBHelper;
import com.example.madproject.Post;
import com.example.madproject.R;
import com.example.madproject.User;

import java.util.Calendar;
import java.util.Date;

public class PostDetailActivity extends AppCompatActivity
{
     EditText Title, Desc,comment;
     ListView cmtView;
     Post selPost;
     Button delButton;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_detail);
        widgets();
        post();
        loadMemory();
        postAdapt();
    }

   public void postAdapt()
    {
        //setting comment adapter
        CommentAdapter cmtAdapt = new CommentAdapter(getApplicationContext(), Comment.nonDeletedPost());
        //setting comment adapters
        cmtView.setAdapter(cmtAdapt);
    }
  public void widgets()
    {
        //finding id of comment view
        cmtView = findViewById(R.id.cmtView);
        //finding the title
        Title = findViewById(R.id.title);
        //finding the description id
        Desc = findViewById(R.id.description);
        //finding the id on delete button
        delButton = findViewById(R.id.delButton);
        //comment id
        comment = findViewById(R.id.comment);
    }
    public void loadMemory()
    {
        //posts loaded
        DBHelper db = DBHelper.instanceOfDatabase(this);
        //cmt array
        db.commentList();
    }


   public void saveComment(View V)
    {
        //db helper
        DBHelper sql = DBHelper.instanceOfDatabase(this);
        //setting Title for post
        String Title = String.valueOf("User");
        //setting description for post
        String Desc = String.valueOf(comment.getText());
        //setting time for post
        Date time = Calendar.getInstance().getTime();

            //get if
            int id1 = selPost.getId();
            //getting new cmt
            Comment newCmt = new Comment(id1, Title, Desc, time.toString() );
            //add new comment
            Comment.commentArrayList.add(newCmt);
            //add comment to database
            sql.addComment(newCmt);


        finish();
    }
    public void post()
    {
        Intent previous = getIntent();
        //intent for extra
        int passID = previous.getIntExtra(Post.POST_EDIT_EXTRA, -1);
        //get post
        selPost = Post.getPostForID(passID);

        if (selPost != null)
        {
            //get title
            Title.setText(selPost.getTitle());
            //get description
            Desc.setText(selPost.getDescription());

        }
        else
        {
            delButton.setVisibility(View.INVISIBLE);
        }
    }
    public void savePost(View V)
    {
        //db helper
        DBHelper sql = DBHelper.instanceOfDatabase(this);
        String title1 = String.valueOf(Title.getText());
        String desc1 = String.valueOf(Desc.getText());
        Date time = Calendar.getInstance().getTime();
        // selected post
        if(selPost == null)
        {
            //set array post
            int id1 = Post.postArrayList.size();
            //for new post
            Post newPost1 = new Post(id1, title1,desc1,time.toString() );
            //post Array list
            Post.postArrayList.add(newPost1);
            //sqlite manager
            sql.addPost(newPost1);
        }
        else
        {
            //set description
            selPost.setDescription(desc1);
            //set title
            selPost.setTitle(title1);
            //uploadpost
            sql.updatePost(selPost);
        }

        finish();
    }

    public void deletePost(View view)
    {
        //delete the post
        selPost.setDeleted(new Date());
        DBHelper sql = DBHelper.instanceOfDatabase(this);
        sql.updatePost(selPost);
        finish();
    }
}