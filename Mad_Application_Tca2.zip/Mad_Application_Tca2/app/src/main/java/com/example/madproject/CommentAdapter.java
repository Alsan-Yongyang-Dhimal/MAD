package com.example.madproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.madproject.Comment;

import java.util.List;

public class CommentAdapter extends ArrayAdapter<Comment> {
    public CommentAdapter(Context context, List<Comment> c) {
        super(context, 0, c);
    }

    @NonNull

    @Override

    public View getView(int position, @Nullable View View, @NonNull ViewGroup parent) {
        //comment
        Comment c = getItem(position);
        //convert view
        if (View == null)
            //post cell
            View = LayoutInflater.from(getContext()).inflate(R.layout.post_cell, parent, false);
        //convert the title
        TextView title1 = View.findViewById(R.id.Title);
        //convert the descr
        TextView desc1 = View.findViewById(R.id.DltUser);
        //convert date
        TextView postedDate =View.findViewById(R.id.Time);


        //set title
        title1.setText(c.getTitle());
        //set description
        desc1.setText(c.getDescription());
        //set date
       postedDate.setText(c.getCommentedDate());

        return View;
    }
}
