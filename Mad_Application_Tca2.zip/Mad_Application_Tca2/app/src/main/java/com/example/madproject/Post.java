package com.example.madproject;

import java.util.ArrayList;
import java.util.Date;

public class Post {
    //array list for post
    public static ArrayList<com.example.madproject.Post> postArrayList = new ArrayList<>();
    //post edit
    public static String POST_EDIT_EXTRA = "postEdit";
    //int id
    private int id;
    //string title
    private String title;
    //String description
    private String description;
    //string post date
    private String postedDate;
    //delete
    private Date deleted;

    public Post(int id, String title, String description, String postedDate, Date deleted) {
        //id
        this.id = id;
        //title
        this.title = title;
        //description
        this.description = description;
        //post date
        this.postedDate = postedDate;
        //delete date
        this.deleted = deleted;
    }

    public Post(int id, String title, String description, String postedDate) {
        //id
        this.id = id;
        //title
        this.title = title;
        //description
        this.description = description;
        //post date
        this.postedDate = postedDate;
        //delete
        deleted = null;
    }

    public static com.example.madproject.Post getPostForID(int passedPostID) {
        //post array
        for (com.example.madproject.Post post : postArrayList) {
            //passing post id
            if (post.getId() == passedPostID)
                return post;
        }

        return null;
    }

    public static ArrayList<com.example.madproject.Post> nonDeletedPost() {
        //array list to delete
        ArrayList<com.example.madproject.Post> nonDeleted = new ArrayList<>();
        //post
        for (com.example.madproject.Post post : postArrayList) {
            //post
            if (post.getDeleted() == null)
                //non delete
                nonDeleted.add(post);
        }

        return nonDeleted;
    }

    //get method for id
    public int getId() {
        return id;
    }

    // set method for id
    public void setId(int id) {
        this.id = id;
    }

    //get method for title
    public String getTitle() {
        return title;
    }

    // set method for title
    public void setTitle(String title) {
        this.title = title;
    }

    //get method for description
    public String getDescription() {
        return description;
    }

    // set method for description
    public void setDescription(String description) {
        this.description = description;
    }

    //get method for post date
    public String getPostedDate() {
        return postedDate;
    }

    // set method for post date
    public void setPostedDate(String postedDate) {
        this.postedDate = postedDate;
    }

    //get method for delete
    public Date getDeleted() {
        return deleted;
    }

    // set method for delete
    public void setDeleted(Date deleted) {
        this.deleted = deleted;
    }
}
