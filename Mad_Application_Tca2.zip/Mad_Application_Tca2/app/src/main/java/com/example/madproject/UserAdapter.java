package com.example.madproject;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.madproject.User;

import java.util.List;

public class UserAdapter extends ArrayAdapter<User>
{
    public UserAdapter(Context context, List<User> users)
    {
        super(context, 0, users);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent)
    {
        //get user
        User user = getItem(position);
        //convert view
        if(convertView == null)
            //get context
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.user_cell, parent, false);
        //set title
        TextView title = convertView.findViewById(R.id.Title);
        //set user
        title.setText(user.getUsername());
        //return
        return convertView;
    }
}