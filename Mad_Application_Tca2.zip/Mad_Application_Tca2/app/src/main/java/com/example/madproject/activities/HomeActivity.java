package com.example.madproject.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.madproject.EditProfileActivity;
import com.example.madproject.User;
import com.example.madproject.DBHelper;
import com.example.madproject.activities.PostDetailActivity;
import com.example.madproject.R;
import com.example.madproject.PostAdapter;
import com.example.madproject.Post;

public class HomeActivity extends AppCompatActivity
{
     ListView post;
     String  recentUsername;
    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Widgets();
        CurrentUser();
        loadMemory();
        Post();
        Click();
    }


    public void Widgets()
    {
        //setup postView
        post = findViewById(R.id.postList);
    }


    private void CurrentUser()
    {
        //getting previous
        Intent pre = getIntent();
        //passing username to recent username
        String passUsername = pre.getStringExtra(User.USER);
        recentUsername =passUsername;


    }
    public void loadMemory()
    {
        //post loaded
        DBHelper db = DBHelper.instanceOfDatabase(this);
       //postList
        db.postList();
    }

    public void Post()
    {
        //post Adapters
        PostAdapter post1 = new PostAdapter(getApplicationContext(), Post.nonDeletedPost());
        //setting adapters
        post.setAdapter(post1);
    }


    public void newPost(View view)
    {
        //using Intent to jump form one activity to another
        Intent newPost = new Intent(getApplicationContext(), PostDetailActivity.class);
        startActivity(newPost);
    }

    public void editProfile(View V)
    {

        Intent edit = new Intent(getApplicationContext(), EditProfileActivity.class);
        //putting extra
        edit.putExtra(User.USER,recentUsername );
        //starting activity
        startActivity(edit);
    }
    public void Click()
    {
        post.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> View, View V, int P, long L)
            {
                //get items
                Post note = (Post) post.getItemAtPosition(P);
                //using intent
                Intent editPost1 = new Intent(HomeActivity.this, PostDetailActivity.class);
                //putting extra post
                editPost1.putExtra(Post .POST_EDIT_EXTRA,note.getId());
                //starting intent
                startActivity(editPost1);
            }
        });
    }


    public void onResume()
    {
        Post();
        // resuming
        super.onResume();
    }
}