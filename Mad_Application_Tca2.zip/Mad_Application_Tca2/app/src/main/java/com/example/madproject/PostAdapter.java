package com.example.madproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.madproject.Post;

import java.util.List;

public class PostAdapter extends ArrayAdapter<Post> {
    public PostAdapter(Context context, List<Post> posts) {
        super(context, 0, posts);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        //post
        Post post = getItem(position);
        //get the post cell
        if (convertView == null)
            //convert
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.post_cell, parent, false);
        //convert title
        TextView title = convertView.findViewById(R.id.Title);
        //convert desc
        TextView desc = convertView.findViewById(R.id.DltUser);
        //convert time
        TextView datePosted = convertView.findViewById(R.id.Time);

        //set title
        title.setText(post.getTitle());
        //set desc
        desc.setText(post.getDescription());
        //set date
        datePosted.setText(post.getPostedDate());

        return convertView;
    }
}