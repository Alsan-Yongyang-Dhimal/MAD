package com.example.madproject;

import java.util.ArrayList;
import java.util.Date;

public class Comment
{
    public static ArrayList<com.example.madproject.Comment> commentArrayList = new ArrayList<>();

    //getting the string, int, date
    public int id;
    //string title
    public String title;
    //string desc
    public String desc;
    // post date
    public String datePosted;
    // date
    public Date del;

    public Comment(int Id, String Title, String Description,String DatePosted, Date Delete)
    {
        //getting all
        this.id = Id;
        //this title
        this.title = Title;
        //this description
        this.desc = Description;
        //this post date
        this.datePosted =DatePosted;
        //this delete
        this.del = Delete;
    }

    public Comment(int Id, String Title, String Description,String DatePosted)
    {
        //getting all
        this.id = Id;
        //this title
        this.title = Title;
        //this description
        this.desc = Description;
        //this post date
        this.datePosted =DatePosted;
        //this delete
        this.del = null;
    }


    public static com.example.madproject.Comment getCommentForId(int postId)
    {
        for (com.example.madproject.Comment C : commentArrayList)
        {

            //get id
            if(C.getId() == postId)

                return C;
        }

        return null ;
    }

    public static ArrayList<com.example.madproject.Comment> nonDeletedPost()
    {
        //array list
        ArrayList<com.example.madproject.Comment> nonDeleted = new ArrayList<>();
        for(com.example.madproject.Comment C : commentArrayList)
        {
            //get deleted
            if(C.getDeleted() == null)

                nonDeleted.add(C);
        }
// not deleted
        return nonDeleted;
    }
    //Get and Set Method for all Id

    public int getId()
    {
        return id;
    }
    //set method
    public void setId(int id)
    {
        this.id = id;
    }
    //get set method for title

    public String getTitle()
    {
        return title;
    }
    //set method
    public void setTitle(String title)
    {
        this.title = title;
    }
  //Get and Set Method

    public String getDescription()
    {
        return desc;
    }
    //set method
//set method
    public void setDescription(String desc)
    {
        this.desc = desc;
    }
    //get set method for comment

    public String getCommentedDate()
    {
        return datePosted;
    }
    //set method
    public void setCommentedDate(String postedDate)
    {
        this.datePosted = postedDate;
    }


    public Date getDeleted()
    {
        return del;
    }
    //Set Method
    public void setDeleted(Date deleted)
    {
        this.del = deleted;
    }
}